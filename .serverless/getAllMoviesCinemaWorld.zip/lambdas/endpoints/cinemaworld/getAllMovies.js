/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ([
/* 0 */,
/* 1 */
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const { nanoid } = __webpack_require__(2);
const Responses = __webpack_require__(3);
const DynamoDB = __webpack_require__(4);

const tableName = process.env.tableName;

const getAllMovies = async (api) => {
  const movies = await DynamoDB.getAll(tableName).catch((err) => {
    console.log("error in loading data", err);
    return null;
  });

  if (!movies) {
    return Responses.failure_400({
      message: "Couldn't retrieve movies",
    });
  }

  return Responses.success_200({ movies });
};

const getMovie = async (api, event) => {
  console.log("event", event);
  if (!event.pathParameters || !event.pathParameters.ID) {
    // no movie ID submitted
    return Responses.failure_400({ message: "Movie ID not submitted." });
  }

  const movieID = event.pathParameters.ID;

  const movie = await DynamoDB.get(movieID, tableName).catch((err) => {
    console.log("error in loading data", err);
    return null;
  });

  if (!movie) {
    return Responses.failure_400({
      message: "Couldn't find a user by given ID",
    });
  }

  return Responses.success_200({ movie });
};

const addMovie = async (api, event) => {
  console.log("event", event);
  if (!event.body) {
    // no movie data submitted
    return Responses.failure_400({ message: "Movie data not submitted." });
  }

  let movie = JSON.parse(event.body);
  // add the ID
  movie.ID = nanoid();

  const newUser = await DynamoDB.write(movie, tableName).catch((err) => {
    console.log("Error in saving the movie");
    return null;
  });

  if (!newUser) {
    return Responses.failure_400({
      message: "Couldn't create a new movie",
    });
  }

  return Responses.success_200({ movie });
};

module.exports = { getAllMovies, getMovie, addMovie };


/***/ }),
/* 2 */
/***/ ((module) => {

"use strict";
module.exports = require("nanoid");;

/***/ }),
/* 3 */
/***/ ((module) => {

const Responses = {
  success_200(data = {}) {
    return {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Methods": "*",
        "Access-Control-Allow-Origin": "*",
      },
      statusCode: 200,
      body: JSON.stringify(data),
    };
  },
  failure_400(data = {}) {
    return {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Methods": "*",
        "Access-Control-Allow-Origin": "*",
      },
      statusCode: 400,
      body: JSON.stringify(data),
    };
  },
};

module.exports = Responses;


/***/ }),
/* 4 */
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const AWS = __webpack_require__(5);

const documentClient = new AWS.DynamoDB.DocumentClient();

const DynamoDB = {
  async getAll(TableName) {
    const params = {
      TableName,
    };

    const scanResults = [];
    let items;
    do {
      items = await documentClient.scan(params).promise();
      items.Items.forEach((item) => scanResults.push(item));
      params.ExclusiveStartKey = items.LastEvaluatedKey;
    } while (typeof items.LastEvaluatedKey !== "undefined");

    return scanResults;
  },

  async get(ID, TableName) {
    const params = {
      TableName,
      Key: {
        ID,
      },
    };

    const data = await documentClient.get(params).promise();

    if (!data || !data.Item) {
      throw Error(`Error fetching data for ID of ${ID} from ${TableName}`);
    }

    return data.Item;
  },

  async write(data, TableName) {
    if (!data.ID) {
      throw Error(`No ID provided`);
    }

    const params = {
      TableName,
      Item: data,
    };

    const response = await documentClient.put(params).promise();
    if (!response) {
      throw Error(`Error saving data ID of ${ID} into the table ${TableName}`);
    }

    return data;
  },
};

module.exports = DynamoDB;


/***/ }),
/* 5 */
/***/ ((module) => {

"use strict";
module.exports = require("aws-sdk");;

/***/ })
/******/ 	]);
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
var exports = __webpack_exports__;
const { getAllMovies } = __webpack_require__(1);

exports.handler = async (event) => {
  return getAllMovies("cinemaworld");
};

})();

var __webpack_export_target__ = exports;
for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ })()
;